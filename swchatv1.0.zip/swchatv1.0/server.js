const http = require('http');
const fs = require('fs');
const path = require('path');
const WebSocket = require('ws');

const PORT = 3000;
const WWW_ROOT = __dirname;

// MIME 类型映射
const MIME_TYPES = {
    '.html': 'text/html; charset=utf-8',
    '.css': 'text/css; charset=utf-8',
    '.js': 'application/javascript; charset=utf-8',
    '.json': 'application/json; charset=utf-8',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.gif': 'image/gif',
    '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon',
};

// ===== HTTP 静态文件服务 =====
const server = http.createServer((req, res) => {
    let filePath = path.join(WWW_ROOT, req.url === '/' ? '/index.html' : req.url);
    const ext = path.extname(filePath);

    // 安全：防止目录遍历
    filePath = path.resolve(filePath);
    if (!filePath.startsWith(WWW_ROOT)) {
        res.writeHead(403);
        res.end('Forbidden');
        return;
    }

    // 默认首页
    if (req.url === '/') {
        filePath = path.join(WWW_ROOT, 'index.html');
    }

    fs.readFile(filePath, (err, data) => {
        if (err) {
            res.writeHead(404);
            res.end('Not Found');
            return;
        }
        const contentType = MIME_TYPES[ext] || 'application/octet-stream';
        res.writeHead(200, { 'Content-Type': contentType });
        res.end(data);
    });
});

// ===== WebSocket 服务 =====
const wss = new WebSocket.Server({ server });

// 状态存储
let visitorIdCounter = 0;
const visitors = new Map();   // visitorId -> { ws, id, ip, ua, connectedAt, agent, status }
const agents = new Set();     // 后台管理端 WebSocket 集合

function getTimeString() {
    const d = new Date();
    return String(d.getHours()).padStart(2, '0') + ':' +
           String(d.getMinutes()).padStart(2, '0');
}

function broadcastVisitorList() {
    const list = [];
    visitors.forEach((v) => {
        list.push({
            id: v.id,
            ip: v.ip,
            ua: v.ua,
            connectedAt: v.connectedAt,
            status: v.status,
        });
    });
    const msg = JSON.stringify({ action: 'visitor-list', data: list });
    agents.forEach((agentWs) => {
        if (agentWs.readyState === WebSocket.OPEN) {
            agentWs.send(msg);
        }
    });
}

wss.on('connection', (ws, req) => {
    const clientIp = req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown';
    const userAgent = req.headers['user-agent'] || '';

    // 通过 URL 参数区分角色：?role=agent 或 ?role=visitor
    const urlParams = new URL(req.url, 'http://localhost').searchParams;
    const role = urlParams.get('role') || 'visitor';

    if (role === 'agent') {
        // ===== 后台管理端 =====
        agents.add(ws);
        console.log(`[Agent] 管理端已连接，当前在线管理端: ${agents.size}`);

        // 发送当前访客列表
        broadcastVisitorList();

        ws.on('message', (raw) => {
            let parsed;
            try { parsed = JSON.parse(raw.toString()); } catch { return; }

            switch (parsed.action) {
                case 'agent-invite': {
                    // 后台邀请某个访客聊天
                    const visitorId = parsed.visitorId;
                    const visitor = visitors.get(visitorId);
                    if (visitor && visitor.ws.readyState === WebSocket.OPEN) {
                        visitor.status = 'chatting';
                        visitor.agent = ws;
                        // 通知访客：客服已接入
                        visitor.ws.send(JSON.stringify({
                            action: 'agent-joined',
                            text: '客服已接入，现在可以开始聊天了！',
                            time: getTimeString(),
                        }));
                        // 通知后台：邀请成功
                        ws.send(JSON.stringify({
                            action: 'agent-invite-ok',
                            visitorId: visitorId,
                        }));
                        broadcastVisitorList();
                    }
                    break;
                }
                case 'agent-message': {
                    // 后台向指定访客发送消息
                    const visitor = visitors.get(parsed.visitorId);
                    if (visitor && visitor.ws.readyState === WebSocket.OPEN) {
                        const msgPayload = JSON.stringify({
                            action: 'agent-message',
                            text: parsed.text,
                            time: getTimeString(),
                        });
                        visitor.ws.send(msgPayload);
                        // 也给后台回显
                        ws.send(JSON.stringify({
                            action: 'agent-message-echo',
                            visitorId: parsed.visitorId,
                            text: parsed.text,
                            time: getTimeString(),
                        }));
                    }
                    break;
                }
                case 'visitor-list': {
                    broadcastVisitorList();
                    break;
                }
            }
        });

        ws.on('close', () => {
            agents.delete(ws);
            console.log(`[Agent] 管理端断开，当前在线管理端: ${agents.size}`);
        });

        ws.on('error', () => {
            agents.delete(ws);
        });

    } else {
        // ===== 访客端 =====
        visitorIdCounter++;
        const visitorId = 'V' + String(visitorIdCounter).padStart(4, '0');
        const visitorInfo = {
            ws: ws,
            id: visitorId,
            ip: clientIp,
            ua: userAgent,
            connectedAt: new Date().toLocaleString('zh-CN'),
            agent: null,
            status: 'waiting',   // waiting | chatting
        };
        visitors.set(visitorId, visitorInfo);
        console.log(`[Visitor] ${visitorId} 已连接 (${clientIp})`);

        // 告知访客其 ID
        ws.send(JSON.stringify({
            action: 'welcome',
            visitorId: visitorId,
            text: '你好呀！👋 欢迎来到我们的网站，有什么可以帮你的吗？',
            time: getTimeString(),
        }));

        // 通知管理端更新列表
        broadcastVisitorList();

        ws.on('message', (raw) => {
            let parsed;
            try { parsed = JSON.parse(raw.toString()); } catch { return; }

            if (parsed.action === 'visitor-message') {
                const msgPayload = {
                    action: 'visitor-message',
                    visitorId: visitorId,
                    text: parsed.text,
                    time: getTimeString(),
                };
                // 发送给对应的后台客服
                if (visitorInfo.agent && visitorInfo.agent.readyState === WebSocket.OPEN) {
                    visitorInfo.agent.send(JSON.stringify(msgPayload));
                } else {
                    // 广播给所有管理端
                    agents.forEach((agentWs) => {
                        if (agentWs.readyState === WebSocket.OPEN) {
                            agentWs.send(JSON.stringify(msgPayload));
                        }
                    });
                }
                // 回显给访客自己
                ws.send(JSON.stringify({
                    action: 'visitor-message-echo',
                    text: parsed.text,
                    time: getTimeString(),
                }));
            }
        });

        ws.on('close', () => {
            visitors.delete(visitorId);
            console.log(`[Visitor] ${visitorId} 断开`);
            broadcastVisitorList();
        });

        ws.on('error', () => {
            visitors.delete(visitorId);
            broadcastVisitorList();
        });
    }
});

server.listen(PORT, () => {
    console.log('');
    console.log('========================================');
    console.log('  SWChat 客服聊天系统已启动');
    console.log('========================================');
    console.log(`  访客端: http://localhost:${PORT}/`);
    console.log(`  管理端: http://localhost:${PORT}/admin.html`);
    console.log('========================================');
    console.log('');
});
