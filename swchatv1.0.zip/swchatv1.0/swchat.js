/**
 * SWChat - 浮动客服聊天外链 JS
 * 
 * 使用方式: <script src="swchat.js"></script>
 * 默认 API 地址: 同目录下的 api.php，可在 <script> 标签上通过 data-api 指定
 * 示例: <script src="swchat.js" data-api="https://example.com/api.php"></script>
 * 
 * 特性: IIFE 隔离，SVG 图标无外部依赖，CSS 高特异性防冲突，兼容任意网站
 */
(function(win, doc) {
    'use strict';

    // ========== 配置 ==========
    var SCRIPT = doc.currentScript || (function() {
        var s = doc.getElementsByTagName('script');
        return s[s.length - 1];
    })();
    var API_URL   = SCRIPT.getAttribute('data-api') || 'http://cha.t400.com.cn/chat/api.php'; // 可自定义 API 地址
    var POLL_MS   = 3000;
    var PREFIX    = 'swchat__';  // 所有 class/html id 统一前缀，避免冲突

    // ========== SVG 图标（替代 Font Awesome，零外部依赖）==========
    var ICONS = {
        chat:   '<svg viewBox="0 0 24 24" fill="currentColor" width="28" height="28"><path d="M20 2H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h14l4 4V4c0-1.1-.9-2-2-2z"/></svg>',
        send:   '<svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>',
        close:  '<svg viewBox="0 0 24 24" fill="currentColor" width="20" height="20"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>',
        agent:  '<svg viewBox="0 0 24 24" fill="currentColor" width="12" height="12"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>',
        smile:  '<svg viewBox="0 0 24 24" fill="currentColor" width="19" height="19"><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2" fill="none" stroke="#94a3b8" stroke-width="1.5" stroke-linecap="round"/><circle cx="9" cy="9.5" r="1.3" fill="#94a3b8"/><circle cx="15" cy="9.5" r="1.3" fill="#94a3b8"/></svg>',
        delete: '<svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>'
    };

    // ========== 注入 CSS ==========
    var STYLE = doc.createElement('style');
    STYLE.textContent = [
        // 聊天按钮 FAB
        '.' + PREFIX + 'fab{position:fixed;bottom:24px;right:24px;width:60px;height:60px;border-radius:50%;background:linear-gradient(135deg,#2563eb,#1d4ed8);color:#fff;border:none;box-shadow:0 8px 28px rgba(37,99,235,.45);display:flex;align-items:center;justify-content:center;cursor:pointer;z-index:2147483640;transition:transform .25s cubic-bezier(.34,1.56,.64,1),box-shadow .25s ease,opacity .3s ease,visibility .3s ease;transform:scale(1);opacity:1;visibility:visible}',
        '.' + PREFIX + 'fab:hover{transform:scale(1.08);box-shadow:0 12px 36px rgba(37,99,235,.5)}',
        '.' + PREFIX + 'fab:active{transform:scale(.92)}',
        '.' + PREFIX + 'fab_hidden{opacity:0!important;visibility:hidden!important;transform:scale(.6)!important;pointer-events:none!important}',
        // 聊天窗口
        '.' + PREFIX + 'win{position:fixed;bottom:24px;right:24px;width:min(400px,92vw);height:min(620px,80vh);background:#fff;border-radius:28px;box-shadow:0 25px 60px -12px rgba(0,0,0,.35),0 8px 24px -6px rgba(0,0,0,.08);display:flex;flex-direction:column;overflow:hidden;z-index:2147483641;transform-origin:bottom right;transition:transform .3s cubic-bezier(.34,1.56,.64,1),opacity .3s ease,visibility .3s ease;transform:scale(1);opacity:1;visibility:visible;border:1px solid rgba(255,255,255,.2)}',
        '.' + PREFIX + 'win_closed{transform:scale(.7)!important;opacity:0!important;visibility:hidden!important;pointer-events:none!important}',
        // 头部
        '.' + PREFIX + 'header{background:linear-gradient(135deg,#2563eb,#1d4ed8);padding:16px 20px;display:flex;align-items:center;gap:12px;flex-shrink:0;border-bottom:1px solid rgba(255,255,255,.1)}',
        '.' + PREFIX + 'avatar{width:44px;height:44px;border-radius:50%;background:rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;color:#fff;border:2px solid rgba(255,255,255,.35);flex-shrink:0;position:relative}',
        '.' + PREFIX + 'avatar_dot{position:absolute;bottom:0;right:0;width:13px;height:13px;background:#22c55e;border-radius:50%;border:2px solid #fff;box-shadow:0 0 0 2px rgba(34,197,94,.3);animation:' + PREFIX + 'pulse 2s infinite}',
        '@keyframes ' + PREFIX + 'pulse{0%,100%{transform:scale(1);opacity:1}50%{transform:scale(1.15);opacity:.8}}',
        '.' + PREFIX + 'hinfo{flex:1;min-width:0}',
        '.' + PREFIX + 'hinfo_h3{font:600 16px/1.2 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;color:#fff;letter-spacing:-.01em;margin:0 0 2px 0}',
        '.' + PREFIX + 'hinfo_st{font-size:12px;color:rgba(255,255,255,.8);display:flex;align-items:center;gap:6px}',
        '.' + PREFIX + 'hinfo_st svg{width:9px;height:9px;color:#22c55e}',
        '.' + PREFIX + 'hact{display:flex;gap:4px;color:rgba(255,255,255,.8)}',
        '.' + PREFIX + 'hact_btn{width:34px;height:34px;border-radius:50%;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:background .2s,color .2s}',
        '.' + PREFIX + 'hact_btn:hover{background:rgba(255,255,255,.15);color:#fff}',
        // 消息区
        '.' + PREFIX + 'msgs{flex:1;padding:18px 16px 12px;overflow-y:auto;display:flex;flex-direction:column;gap:14px;background:#f8fafc;scroll-behavior:smooth}',
        '.' + PREFIX + 'msgs::-webkit-scrollbar{width:4px}',
        '.' + PREFIX + 'msgs::-webkit-scrollbar-track{background:#f1f5f9;border-radius:4px}',
        '.' + PREFIX + 'msgs::-webkit-scrollbar-thumb{background:#cbd5e1;border-radius:4px}',
        '.' + PREFIX + 'msgs::-webkit-scrollbar-thumb:hover{background:#94a3b8}',
        // 消息
        '.' + PREFIX + 'msg{max-width:88%;display:flex;flex-direction:column;animation:' + PREFIX + 'msgIn .25s ease-out}',
        '@keyframes ' + PREFIX + 'msgIn{0%{opacity:0;transform:translateY(12px) scale(.97)}100%{opacity:1;transform:translateY(0) scale(1)}}',
        '.' + PREFIX + 'msg_user{align-self:flex-end;align-items:flex-end}',
        '.' + PREFIX + 'msg_agent{align-self:flex-start;align-items:flex-start}',
        '.' + PREFIX + 'bubble{padding:10px 15px;border-radius:18px;font:14.5px/1.55 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;word-break:break-word;box-shadow:0 1px 3px rgba(0,0,0,.04);position:relative}',
        '.' + PREFIX + 'msg_user .' + PREFIX + 'bubble{background:linear-gradient(135deg,#2563eb,#1d4ed8);color:#fff;border-bottom-right-radius:4px}',
        '.' + PREFIX + 'msg_agent .' + PREFIX + 'bubble{background:#fff;color:#0f172a;border-bottom-left-radius:4px;border:1px solid #e9edf2;box-shadow:0 2px 6px rgba(0,0,0,.03)}',
        '.' + PREFIX + 'msg_agent .' + PREFIX + 'bubble:before{content:"";position:absolute;left:-7px;top:12px;width:0;height:0;border:7px solid transparent;border-right-color:#fff;border-left:0;filter:drop-shadow(-1px 0 0 #e9edf2)}',
        '.' + PREFIX + 'msg_time{font-size:11px;color:#94a3b8;margin-top:4px;padding:0 6px;letter-spacing:.01em}',
        '.' + PREFIX + 'msg_meta{display:flex;align-items:center;gap:8px}',
        '.' + PREFIX + 'msg_avt{width:26px;height:26px;border-radius:50%;background:#dbeafe;color:#2563eb;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:600;margin-bottom:4px;border:1px solid #bfdbfe;flex-shrink:0}',
        '.' + PREFIX + 'msg_mname{font:500 12px -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;color:#1e293b}',
        // 打字指示器
        '.' + PREFIX + 'typing{display:flex;align-items:center;gap:10px;padding:6px 0 4px;align-self:flex-start;opacity:0;visibility:hidden;transition:opacity .2s,visibility .2s}',
        '.' + PREFIX + 'typing_show{opacity:1!important;visibility:visible!important}',
        '.' + PREFIX + 'typing_dots{display:flex;gap:5px;background:#fff;padding:10px 16px;border-radius:30px;border:1px solid #e9edf2;box-shadow:0 2px 6px rgba(0,0,0,.03)}',
        '.' + PREFIX + 'typing_dots span{width:8px;height:8px;background:#94a3b8;border-radius:50%;animation:' + PREFIX + 'dotB 1.4s infinite ease-in-out}',
        '.' + PREFIX + 'typing_dots span:nth-child(2){animation-delay:.2s}',
        '.' + PREFIX + 'typing_dots span:nth-child(3){animation-delay:.4s}',
        '@keyframes ' + PREFIX + 'dotB{0%,60%,100%{transform:translateY(0);background:#94a3b8}30%{transform:translateY(-8px);background:#2563eb}}',
        '.' + PREFIX + 'typing_lbl{font:12px -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;color:#64748b}',
        // 底部输入
        '.' + PREFIX + 'footer{padding:12px 16px 16px;background:#fff;border-top:1px solid #f1f5f9;flex-shrink:0;display:flex;align-items:flex-end;gap:10px}',
        '.' + PREFIX + 'iwrap{flex:1;background:#f1f5f9;border-radius:28px;padding:3px 6px 3px 16px;display:flex;align-items:flex-end;border:1px solid transparent;transition:border .2s,background .2s,box-shadow .2s}',
        '.' + PREFIX + 'iwrap_focus{border-color:#2563eb!important;background:#fff!important;box-shadow:0 0 0 4px rgba(37,99,235,.08)!important}',
        '.' + PREFIX + 'textarea{flex:1;border:none;outline:none;resize:none;background:transparent;padding:8px 0;font:14.5px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;max-height:90px;min-height:20px;color:#0f172a;margin:0}',
        '.' + PREFIX + 'textarea::placeholder{color:#94a3b8;font-weight:400;font-family:inherit}',
        '.' + PREFIX + 'emojibtn{background:none;border:none;color:#94a3b8;cursor:pointer;padding:8px 4px 8px 0;transition:color .2s;line-height:1}',
        '.' + PREFIX + 'emojibtn:hover{color:#2563eb}',
        '.' + PREFIX + 'sendbtn{width:44px;height:44px;border-radius:50%;border:none;background:linear-gradient(135deg,#2563eb,#1d4ed8);color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:transform .15s,box-shadow .2s,background .2s;flex-shrink:0;box-shadow:0 4px 12px rgba(37,99,235,.35)}',
        '.' + PREFIX + 'sendbtn:hover{transform:scale(1.05);box-shadow:0 8px 20px rgba(37,99,235,.4);background:linear-gradient(135deg,#3b82f6,#2563eb)}',
        '.' + PREFIX + 'sendbtn:active{transform:scale(.92)}',
        // 留言窗口
        '.' + PREFIX + 'leave_win{position:fixed;bottom:24px;right:24px;width:min(400px,92vw);height:min(620px,80vh);background:#fff;border-radius:28px;box-shadow:0 25px 60px -12px rgba(0,0,0,.35),0 8px 24px -6px rgba(0,0,0,.08);display:flex;flex-direction:column;overflow:hidden;z-index:2147483641;transform-origin:bottom right;transition:transform .3s cubic-bezier(.34,1.56,.64,1),opacity .3s ease,visibility .3s ease;transform:scale(1);opacity:1;visibility:visible;border:1px solid rgba(255,255,255,.2)}',
        '.' + PREFIX + 'leave_win_closed{transform:scale(.7)!important;opacity:0!important;visibility:hidden!important;pointer-events:none!important}',
        '.' + PREFIX + 'leave_body{flex:1;padding:24px 20px 16px;overflow-y:auto;background:#f8fafc}',
        '.' + PREFIX + 'leave_field{margin-bottom:18px}',
        '.' + PREFIX + 'leave_label{display:block;font:600 13px -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;color:#334155;margin-bottom:6px}',
        '.' + PREFIX + 'leave_input{width:100%;padding:10px 14px;border:1.5px solid #e2e8f0;border-radius:12px;font:14px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;background:#fff;color:#0f172a;outline:none;transition:border .2s,box-shadow .2s;box-sizing:border-box}',
        '.' + PREFIX + 'leave_input:focus{border-color:#2563eb;box-shadow:0 0 0 4px rgba(37,99,235,.08)}',
        '.' + PREFIX + 'leave_textarea{width:100%;min-height:100px;padding:10px 14px;border:1.5px solid #e2e8f0;border-radius:12px;font:14px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;background:#fff;color:#0f172a;outline:none;resize:vertical;transition:border .2s,box-shadow .2s;box-sizing:border-box}',
        '.' + PREFIX + 'leave_textarea:focus{border-color:#2563eb;box-shadow:0 0 0 4px rgba(37,99,235,.08)}',
        '.' + PREFIX + 'leave_submit{width:100%;padding:12px 0;border:none;border-radius:14px;background:linear-gradient(135deg,#2563eb,#1d4ed8);color:#fff;font:600 15px -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;cursor:pointer;transition:transform .15s,box-shadow .2s;box-shadow:0 4px 14px rgba(37,99,235,.35)}',
        '.' + PREFIX + 'leave_submit:hover{transform:translateY(-1px);box-shadow:0 8px 24px rgba(37,99,235,.4)}',
        '.' + PREFIX + 'leave_submit:active{transform:scale(.97)}',
        '.' + PREFIX + 'leave_footer{padding:14px 20px 20px;background:#fff;border-top:1px solid #f1f5f9}',
        '.' + PREFIX + 'leave_tip{font:13px/1.6 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;color:#64748b;text-align:center}',
        '.' + PREFIX + 'leave_tip strong{color:#2563eb;font-weight:600}',
        '.' + PREFIX + 'leave_success{display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;gap:12px;color:#334155;font:15px/1.6 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;text-align:center;padding:20px}',
        '.' + PREFIX + 'leave_success svg{color:#22c55e}',
        '.' + PREFIX + 'leave_close_btn{width:34px;height:34px;border-radius:50%;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:background .2s,color .2s;color:rgba(255,255,255,.8)}',
        '.' + PREFIX + 'leave_close_btn:hover{background:rgba(255,255,255,.15);color:#fff}',
        // 响应式
        '@media(max-width:480px){.' + PREFIX + 'win{bottom:12px;right:12px;width:calc(100vw - 24px);height:calc(100vh - 100px);border-radius:24px}.' + PREFIX + 'fab{bottom:18px;right:18px;width:56px;height:56px}.' + PREFIX + 'header{padding:14px 16px}.' + PREFIX + 'footer{padding:10px 12px 14px}.' + PREFIX + 'leave_win{bottom:12px;right:12px;width:calc(100vw - 24px);height:calc(100vh - 100px);border-radius:24px}}'
    ].join('\n');
    doc.head.appendChild(STYLE);

    // ========== DOM 构建 ==========

    // 浮动按钮
    var fab = doc.createElement('button');
    fab.className = PREFIX + 'fab ' + PREFIX + 'fab_hidden';
    fab.innerHTML = ICONS.chat;
    fab.setAttribute('aria-label', '打开客服聊天');
    fab.style.display = 'flex';
    doc.body.appendChild(fab);

    // 聊天窗口
    var win = doc.createElement('div');
    win.className = PREFIX + 'win ' + PREFIX + 'win_closed';
    win.innerHTML =
        '<div class="' + PREFIX + 'header">' +
        '  <div class="' + PREFIX + 'avatar">' +
             ICONS.agent +
        '    <span class="' + PREFIX + 'avatar_dot"></span>' +
        '  </div>' +
        '  <div class="' + PREFIX + 'hinfo">' +
        '    <h3 class="' + PREFIX + 'hinfo_h3">赵子扬 · 客服</h3>' +
        '    <div class="' + PREFIX + 'hinfo_st"><svg viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="12" r="6"/></svg> 在线 · 通常秒回</div>' +
        '  </div>' +
        '  <div class="' + PREFIX + 'hact"><span class="' + PREFIX + 'hact_btn">' + ICONS.delete + '</span><span class="' + PREFIX + 'hact_btn">' + ICONS.close + '</span></div>' +
        '</div>' +
        '<div class="' + PREFIX + 'msgs" id="' + PREFIX + 'msgs">' +
        '  <div class="' + PREFIX + 'typing" id="' + PREFIX + 'typing">' +
        '    <div class="' + PREFIX + 'typing_dots"><span></span><span></span><span></span></div>' +
        '    <span class="' + PREFIX + 'typing_lbl">赵子扬正在输入...</span>' +
        '  </div>' +
        '</div>' +
        '<div class="' + PREFIX + 'footer">' +
        '  <div class="' + PREFIX + 'iwrap" id="' + PREFIX + 'iwrap">' +
        '    <textarea class="' + PREFIX + 'textarea" id="' + PREFIX + 'input" rows="1" placeholder="输入消息..."></textarea>' +
        '    <button class="' + PREFIX + 'emojibtn">' + ICONS.smile + '</button>' +
        '  </div>' +
        '  <button class="' + PREFIX + 'sendbtn" id="' + PREFIX + 'send">' + ICONS.send + '</button>' +
        '</div>';
    doc.body.appendChild(win);

    // 留言窗口
    var leaveWin = doc.createElement('div');
    leaveWin.className = PREFIX + 'leave_win ' + PREFIX + 'leave_win_closed';
    leaveWin.innerHTML =
        '<div class="' + PREFIX + 'header">' +
        '  <div class="' + PREFIX + 'avatar">' +
             ICONS.agent +
        '  </div>' +
        '  <div class="' + PREFIX + 'hinfo">' +
        '    <h3 class="' + PREFIX + 'hinfo_h3">赵子扬 · 客服</h3>' +
        '    <div class="' + PREFIX + 'hinfo_st" style="color:#fbbf24"><svg viewBox="0 0 24 24" fill="currentColor" width="9" height="9"><circle cx="12" cy="12" r="6"/></svg> 离线 · 请留言</div>' +
        '  </div>' +
        '  <div class="' + PREFIX + 'hact"><span class="' + PREFIX + 'leave_close_btn">' + ICONS.close + '</span></div>' +
        '</div>' +
        '<div class="' + PREFIX + 'leave_body" id="' + PREFIX + 'leave_body">' +
        '  <div class="' + PREFIX + 'leave_field">' +
        '    <label class="' + PREFIX + 'leave_label">您的称呼</label>' +
        '    <input class="' + PREFIX + 'leave_input" id="' + PREFIX + 'leave_name" placeholder="请输入您的称呼" maxlength="30">' +
        '  </div>' +
        '  <div class="' + PREFIX + 'leave_field">' +
        '    <label class="' + PREFIX + 'leave_label">您的手机</label>' +
        '    <input class="' + PREFIX + 'leave_input" id="' + PREFIX + 'leave_phone" placeholder="请输入您的手机号码" maxlength="20">' +
        '  </div>' +
        '  <div class="' + PREFIX + 'leave_field">' +
        '    <label class="' + PREFIX + 'leave_label">您的诉求</label>' +
        '    <textarea class="' + PREFIX + 'leave_textarea" id="' + PREFIX + 'leave_content" placeholder="请描述您的问题或需求..." maxlength="500"></textarea>' +
        '  </div>' +
        '  <button class="' + PREFIX + 'leave_submit" id="' + PREFIX + 'leave_submit">提交留言</button>' +
        '</div>' +
        '<div class="' + PREFIX + 'leave_footer">' +
        '  <p class="' + PREFIX + 'leave_tip">留下联系方式，客服会立刻给您回电。<br>您也可以致电 <strong>400-999-0004</strong></p>' +
        '</div>';
    doc.body.appendChild(leaveWin);

    // ========== DOM 引用 ==========
    var msgsEl   = doc.getElementById(PREFIX + 'msgs');
    var inputEl  = doc.getElementById(PREFIX + 'input');
    var sendEl   = doc.getElementById(PREFIX + 'send');
    var typingEl = doc.getElementById(PREFIX + 'typing');
    var iwrapEl  = doc.getElementById(PREFIX + 'iwrap');
    var hactBtns = win.querySelectorAll('.' + PREFIX + 'hact_btn');
    var deleteEl = hactBtns[0];
    var closeEl  = hactBtns[1];
    var statusEl = win.querySelector('.' + PREFIX + 'hinfo_st');
    var leaveCloseEl = leaveWin.querySelector('.' + PREFIX + 'leave_close_btn');
    var leaveSubmitEl = doc.getElementById(PREFIX + 'leave_submit');
    var leaveBodyEl   = doc.getElementById(PREFIX + 'leave_body');

    // ========== 状态 ==========
    var AGENT_NAME = '赵子扬';
    var VISITOR_KEY = 'swchat_visitor_name';
    var MSG_STORE_PREFIX = 'swchat_msgs_';
    var visitorName = getVisitorName();
    var invited = false;
    var agentOnline = false;
    var receivedMsgIds = {};
    var soundAudio = null;

    function getVisitorName() {
        var n = null;
        try { n = localStorage.getItem(VISITOR_KEY); } catch(e){}
        if (!n) {
            n = '访客' + Math.floor(Math.random() * 9000 + 1000);
            try { localStorage.setItem(VISITOR_KEY, n); } catch(e){}
            fetchNameFromServer();
        }
        return n;
    }

    function msgStoreKey() { return MSG_STORE_PREFIX + visitorName; }

    function fetchNameFromServer() {
        var x = new XMLHttpRequest();
        x.open('GET', API_URL + '?action=get_name', true);
        x.onload = function() {
            if (x.status === 200) {
                try {
                    var d = JSON.parse(x.responseText);
                    if (d.name) {
                        visitorName = d.name;
                        try { localStorage.setItem(VISITOR_KEY, visitorName); } catch(e){}
                    }
                } catch(e){}
            }
        };
        x.send();
    }

    // ========== UI 操作 ==========
    function openWin() {
        leaveWin.classList.add(PREFIX + 'leave_win_closed');
        win.classList.remove(PREFIX + 'win_closed');
        fab.classList.add(PREFIX + 'fab_hidden');
        setTimeout(function() { inputEl.focus(); scrollBottom(); }, 150);
    }

    function closeWin() {
        win.classList.add(PREFIX + 'win_closed');
        fab.classList.remove(PREFIX + 'fab_hidden');
    }

    // ===== 删除聊天记录 =====
    function deleteWin() {
        if (!confirm('确定要删除所有聊天记录吗？此操作不可撤销。')) {
            return;
        }
        var x = new XMLHttpRequest();
        x.open('POST', API_URL + '?action=delete_visitor_messages', true);
        x.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        x.onload = function() {
            if (x.status === 200) {
                try {
                    var d = JSON.parse(x.responseText);
                    if (d.success) {
                        msgsEl.innerHTML = '';
                        closeWin();
                    }
                } catch(e) {}
            }
        };
        x.send('name=' + encodeURIComponent(visitorName));
    }

    function openLeaveWin() {
        win.classList.add(PREFIX + 'win_closed');
        leaveWin.classList.remove(PREFIX + 'leave_win_closed');
        fab.classList.add(PREFIX + 'fab_hidden');
        // 清空表单
        doc.getElementById(PREFIX + 'leave_name').value = visitorName;
        doc.getElementById(PREFIX + 'leave_phone').value = '';
        doc.getElementById(PREFIX + 'leave_content').value = '';
        // 恢复表单视图
        leaveBodyEl.innerHTML = leaveBodyEl.getAttribute('data-original') || leaveBodyEl.innerHTML;
        if (!leaveBodyEl.getAttribute('data-original')) {
            leaveBodyEl.setAttribute('data-original', leaveBodyEl.innerHTML);
        }
    }

    function closeLeaveWin() {
        leaveWin.classList.add(PREFIX + 'leave_win_closed');
        fab.classList.remove(PREFIX + 'fab_hidden');
    }

    function updateStatus(text) {
        statusEl.innerHTML = '<svg viewBox="0 0 24 24" fill="currentColor" width="9" height="9"><circle cx="12" cy="12" r="6"/></svg> ' + text;
    }

    function scrollBottom() {
        setTimeout(function() { msgsEl.scrollTop = msgsEl.scrollHeight; }, 20);
    }

    // ========== 消息 ==========
    function getTimeStr() {
        var d = new Date();
        return ('0'+d.getHours()).slice(-2) + ':' + ('0'+d.getMinutes()).slice(-2);
    }

    function addMessage(text, type, timeStr) {
        var time = timeStr || getTimeStr();
        var div = doc.createElement('div');
        div.className = PREFIX + 'msg ' + PREFIX + 'msg_' + type;

        if (type === 'agent') {
            var meta = doc.createElement('div');
            meta.className = PREFIX + 'msg_meta';
            var avt = doc.createElement('div');
            avt.className = PREFIX + 'msg_avt';
            avt.innerHTML = ICONS.agent;
            var nm = doc.createElement('span');
            nm.className = PREFIX + 'msg_mname';
            nm.textContent = AGENT_NAME;
            meta.appendChild(avt);
            meta.appendChild(nm);
            div.appendChild(meta);
        }

        var bub = doc.createElement('div');
        bub.className = PREFIX + 'bubble';
        bub.textContent = text;
        div.appendChild(bub);

        var t = doc.createElement('span');
        t.className = PREFIX + 'msg_time';
        t.textContent = time;
        div.appendChild(t);

        msgsEl.insertBefore(div, typingEl);
        scrollBottom();
    }

    function playSound() {
        if (!soundAudio) {
            soundAudio = new Audio('http://img8.dfco.cn/swchat/xm3527.mp3');
        }
        soundAudio.currentTime = 0;
        soundAudio.play().catch(function(){});
    }

    // ========== 持久化 ==========
    function saveMessages() {
        var bubbles = msgsEl.querySelectorAll('.' + PREFIX + 'msg');
        var list = [];
        for (var i = 0; i < bubbles.length; i++) {
            var el = bubbles[i];
            var type = el.classList.contains(PREFIX + 'msg_agent') ? 'agent' : 'user';
            var bubEl = el.querySelector('.' + PREFIX + 'bubble');
            var timeEl = el.querySelector('.' + PREFIX + 'msg_time');
            if (bubEl) {
                list.push({ text: bubEl.textContent, type: type, time: timeEl ? timeEl.textContent : '' });
            }
        }
        try { localStorage.setItem(msgStoreKey(), JSON.stringify(list)); } catch(e){}
    }

    function loadHistory() {
        try {
            var raw = localStorage.getItem(msgStoreKey());
            if (raw) {
                var list = JSON.parse(raw);
                for (var i = 0; i < list.length; i++) {
                    addMessage(list[i].text, list[i].type, list[i].time);
                }
            }
        } catch(e){}
    }

    // ========== 发送 ==========
    function sendMsg() {
        var text = inputEl.value.trim();
        if (!text) return;

        addMessage(text, 'user');
        inputEl.value = '';
        autoResize();
        inputEl.focus();

        var x = new XMLHttpRequest();
        x.open('POST', API_URL + '?action=send', true);
        x.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        x.send('name=' + encodeURIComponent(visitorName) + '&message=' + encodeURIComponent(text));

        saveMessages();
    }

    function autoResize() {
        inputEl.style.height = 'auto';
        inputEl.style.height = Math.min(inputEl.scrollHeight, 90) + 'px';
    }

    // ========== 轮询 ==========
    function poll() {
        var x = new XMLHttpRequest();
        x.open('GET', API_URL + '?action=poll&name=' + encodeURIComponent(visitorName) + '&_=' + Date.now(), true);
        x.onload = function() {
            if (x.status !== 200) {
                agentOnline = false;
                return;
            }
            try {
                var d = JSON.parse(x.responseText);
                handlePoll(d);
            } catch(e) {
                agentOnline = false;
            }
        };
        x.onerror = function() {
            agentOnline = false;
        };
        x.send();
    }

    function handlePoll(data) {
        // 更新管理员在线状态
        var prevOnline = agentOnline;
        if (typeof data.admin_online !== 'undefined') {
            agentOnline = data.admin_online;
        }

        // 管理员下线 → 主动关闭聊天窗口，打开留言窗口
        if (prevOnline && !agentOnline && !win.classList.contains(PREFIX + 'win_closed')) {
            addMessage('客服已离线，您可以留言，我们会尽快回复。', 'agent');
            openLeaveWin();
        }

        // 管理员上线 → 关闭留言窗口，恢复聊天窗口
        if (!prevOnline && agentOnline && !leaveWin.classList.contains(PREFIX + 'leave_win_closed')) {
            addMessage('客服已上线，继续为您服务。', 'agent');
            openWin();
        }

        // 邀请通知 —— 仅管理员在线时才弹出
        if (data.invited && data.admin_online) {
            if (!invited) {
                invited = true;
                agentOnline = true;
                updateStatus('客服已接入');
                addMessage('您好，客服已接入，请问有什么可以帮您的？', 'agent');
                if (win.classList.contains(PREFIX + 'win_closed') || !leaveWin.classList.contains(PREFIX + 'leave_win_closed')) {
                    openWin();
                }
            }
        } else if (data.invited && !invited) {
            // 管理员离线，仅记录状态，不弹窗
            invited = true;
        }

        // 状态显示：以 agentOnline 为准（admin_online 已在函数开头同步到 agentOnline）
        if (agentOnline) {
            updateStatus('在线 · 通常秒回');
        } else {
            updateStatus('离线 · 请留言');
        }

        var msgs = data.messages || [];
        var hasNew = false;
        for (var i = 0; i < msgs.length; i++) {
            var m = msgs[i];
            if (!receivedMsgIds[m.id]) {
                receivedMsgIds[m.id] = true;
                addMessage(m.text, 'agent', m.time || undefined);
                if (m.auto_open) hasNew = true;
            }
        }

        // 管理员主动发消息自动弹出窗口 + 提示音（仅在线时）
        if (hasNew && win.classList.contains(PREFIX + 'win_closed') && agentOnline) {
            playSound();
            openWin();
        } else if (msgs.length > 0) {
            playSound();
        }

        saveMessages();
    }

    // ========== 事件绑定 ==========
    fab.addEventListener('click', function() {
        if (agentOnline) {
            openWin();
        } else {
            openLeaveWin();
        }
    });
    closeEl.addEventListener('click', closeWin);
    deleteEl.addEventListener('click', deleteWin);
    leaveCloseEl.addEventListener('click', closeLeaveWin);

    inputEl.addEventListener('input', autoResize);
    inputEl.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' && !e.shiftKey && !e.ctrlKey) {
            e.preventDefault();
            sendMsg();
        }
    });

    sendEl.addEventListener('click', sendMsg);

    // 输入框焦点样式
    iwrapEl.addEventListener('focusin', function() { iwrapEl.classList.add(PREFIX + 'iwrap_focus'); });
    iwrapEl.addEventListener('focusout', function() {
        setTimeout(function() {
            if (!iwrapEl.contains(doc.activeElement)) {
                iwrapEl.classList.remove(PREFIX + 'iwrap_focus');
            }
        }, 0);
    });

    // 表情按钮
    win.querySelector('.' + PREFIX + 'emojibtn').addEventListener('click', function() {
        var emojis = ['😊','😂','❤️','🔥','👍','🎉','✨','💪','🤗','😎'];
        var e = emojis[Math.floor(Math.random() * emojis.length)];
        var s = inputEl.selectionStart, end = inputEl.selectionEnd;
        var v = inputEl.value;
        inputEl.value = v.substring(0, s) + e + v.substring(end);
        inputEl.focus();
        var np = s + e.length;
        inputEl.setSelectionRange(np, np);
        autoResize();
    });

    // 留言提交
    leaveSubmitEl.addEventListener('click', function() {
        var n = doc.getElementById(PREFIX + 'leave_name').value.trim();
        var p = doc.getElementById(PREFIX + 'leave_phone').value.trim();
        var c = doc.getElementById(PREFIX + 'leave_content').value.trim();

        if (!n) { alert('请输入您的称呼'); return; }
        if (!p) { alert('请输入您的手机号码'); return; }
        if (!c) { alert('请描述您的诉求'); return; }

        leaveSubmitEl.disabled = true;
        leaveSubmitEl.textContent = '提交中...';

        var x = new XMLHttpRequest();
        x.open('POST', API_URL + '?action=leave_message', true);
        x.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        x.onload = function() {
            if (x.status === 200) {
                try {
                    var d = JSON.parse(x.responseText);
                    if (d.success) {
                        leaveBodyEl.innerHTML = '<div class="' + PREFIX + 'leave_success">' +
                            '<svg viewBox="0 0 24 24" fill="currentColor" width="48" height="48"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>' +
                            '<div>留言已提交成功！<br><span style="font-size:14px;color:#64748b">客服会尽快给您回电</span></div>' +
                        '</div>';
                    }
                } catch(e){}
            }
        };
        x.onerror = function() {
            alert('提交失败，请重试');
            leaveSubmitEl.disabled = false;
            leaveSubmitEl.textContent = '提交留言';
        };
        x.send('name=' + encodeURIComponent(n) + '&phone=' + encodeURIComponent(p) + '&content=' + encodeURIComponent(c));
    });

    // ========== 启动 ==========
    // 初始状态：按钮隐藏，窗口关闭
    fab.classList.remove(PREFIX + 'fab_hidden');
    loadHistory();
    if (msgsEl.querySelectorAll('.' + PREFIX + 'msg').length === 0) {
        addMessage('你好呀！欢迎来到我们的网站，有什么可以帮你的吗？', 'agent');
    }
    setInterval(poll, POLL_MS);
    poll();

})(window, document);
