<?php
/**
 * SWChat API - 纯 PHP 5.2 聊天后台接口
 * 数据存储: JSON 文件（无需数据库）
 * 通信方式: AJAX 轮询
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Cache-Control: no-cache, must-revalidate');

$action = isset($_GET['action']) ? $_GET['action'] : '';

// 数据目录和文件路径
$data_dir = dirname(__FILE__) . '/data';
if (!is_dir($data_dir)) {
    mkdir($data_dir, 0777, true);
}

$msg_file = $data_dir . '/messages.json';
$visitor_file = $data_dir . '/visitors.json';

// ==================== 辅助函数 ====================

/**
 * 读取 JSON 文件（带共享锁）
 */
function read_json($file) {
    if (!file_exists($file)) {
        return array();
    }
    $fp = fopen($file, 'r');
    if (!$fp) {
        return array();
    }
    $locked = flock($fp, LOCK_SH);
    $content = '';
    while (!feof($fp)) {
        $chunk = fread($fp, 8192);
        if ($chunk === false) break;
        $content .= $chunk;
    }
    if ($locked) {
        flock($fp, LOCK_UN);
    }
    fclose($fp);
    if ($content === '') {
        return array();
    }
    $data = json_decode($content, true);
    return is_array($data) ? $data : array();
}

/**
 * 写入 JSON 文件（带排他锁）
 */
function write_json($file, $data) {
    $fp = fopen($file, 'c+');
    if (!$fp) {
        return false;
    }
    if (flock($fp, LOCK_EX)) {
        ftruncate($fp, 0);
        rewind($fp);
        fwrite($fp, json_encode($data));
        fflush($fp);
        flock($fp, LOCK_UN);
        fclose($fp);
        return true;
    }
    fclose($fp);
    return false;
}

/**
 * 获取客户端真实 IP
 */
function get_ip() {
    if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $parts = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        return trim($parts[0]);
    }
    if (isset($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    }
    return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '127.0.0.1';
}

/**
 * 获取当前时间字符串
 */
function now() {
    return date('Y-m-d H:i:s');
}

/**
 * 输出 JSON 并终止
 */
function json_out($data) {
    echo json_encode($data);
    exit;
}

/**
 * 输出错误并终止
 */
function json_error($msg) {
    echo json_encode(array('error' => $msg));
    exit;
}

// ==================== 动作路由 ====================

switch ($action) {

    // ---- 访客发送消息 ----
    case 'send':
        action_send();
        break;

    // ---- 访客轮询新消息 ----
    case 'poll':
        action_poll();
        break;

    // ---- 获取在线访客列表 ----
    case 'visitors':
        action_visitors();
        break;

    // ---- 管理员轮询 ----
    case 'admin_poll':
        action_admin_poll();
        break;

    // ---- 管理员发送消息给指定访客 ----
    case 'admin_send':
        action_admin_send();
        break;

    // ---- 管理员邀请指定访客 ----
    case 'admin_invite':
        action_admin_invite();
        break;

    default:
        json_error('Unknown action: ' . $action);
}

// ==================== 动作实现 ====================

/**
 * 访客发送消息
 * GET: ?action=send&name=xxx&message=xxx
 */
function action_send() {
    global $msg_file, $visitor_file;

    $name = isset($_GET['name']) ? trim($_GET['name']) : '';
    $message = isset($_GET['message']) ? trim($_GET['message']) : '';

    if ($name === '') {
        json_error('name is required');
    }
    if ($message === '') {
        json_error('message is required');
    }

    // 读取消息列表
    $messages = read_json($msg_file);
    $new_id = count($messages) + 1;

    // 添加新消息
    $msg = array(
        'id' => $new_id,
        'from' => $name,
        'from_type' => 'visitor',
        'to' => 'admin',
        'text' => $message,
        'time' => now(),
        'read' => false
    );
    $messages[] = $msg;
    write_json($msg_file, $messages);

    // 更新访客在线状态
    update_visitor($name);

    json_out(array(
        'success' => true,
        'id' => $new_id,
        'time' => $msg['time']
    ));
}

/**
 * 访客轮询 - 检查管理员发来的新消息
 * GET: ?action=poll&name=xxx
 */
function action_poll() {
    global $msg_file, $visitor_file;

    $name = isset($_GET['name']) ? trim($_GET['name']) : '';
    if ($name === '') {
        json_error('name is required');
    }

    // 更新访客在线状态
    update_visitor($name);

    // 读取消息
    $messages = read_json($msg_file);
    $unread = array();
    $invited = false;

    // 查找发给该访客的未读消息（来自 admin）
    $new_messages = array();
    foreach ($messages as $k => $m) {
        if ($m['to'] === $name && $m['from'] === 'admin' && !$m['read']) {
            $new_messages[] = $m;
            $messages[$k]['read'] = true;
        }
    }

    // 标记为已读
    if (count($new_messages) > 0) {
        write_json($msg_file, $messages);
    }

    // 检查是否被邀请
    $visitors = read_json($visitor_file);
    if (isset($visitors[$name]) && isset($visitors[$name]['invited']) && $visitors[$name]['invited']) {
        $invited = true;
    }

    json_out(array(
        'success' => true,
        'messages' => $new_messages,
        'invited' => $invited
    ));
}

/**
 * 获取在线访客列表
 * GET: ?action=visitors
 */
function action_visitors() {
    global $visitor_file;

    $visitors = read_json($visitor_file);
    $online = array();
    $cutoff = time() - 6; // 3秒轮询 × 2 容错

    foreach ($visitors as $name => $info) {
        $last = isset($info['last_poll']) ? intval($info['last_poll']) : 0;
        if ($last >= $cutoff) {
            $online[] = array(
                'name' => $name,
                'ip' => isset($info['ip']) ? $info['ip'] : '',
                'first_seen' => isset($info['first_seen']) ? $info['first_seen'] : '',
                'last_poll' => $last,
                'invited' => isset($info['invited']) ? $info['invited'] : false
            );
        }
    }

    json_out(array(
        'success' => true,
        'visitors' => $online
    ));
}

/**
 * 管理员轮询 - 获取新消息和在线访客
 * GET: ?action=admin_poll
 */
function action_admin_poll() {
    global $msg_file, $visitor_file;

    $messages = read_json($msg_file);
    $visitors = read_json($visitor_file);

    // 清理过期访客并构建在线列表
    $cutoff = time() - 6;
    $online = array();
    $clean = false;

    foreach ($visitors as $name => $info) {
        $last = isset($info['last_poll']) ? intval($info['last_poll']) : 0;
        if ($last >= $cutoff) {
            $online[] = array(
                'name' => $name,
                'ip' => isset($info['ip']) ? $info['ip'] : '',
                'first_seen' => isset($info['first_seen']) ? $info['first_seen'] : '',
                'last_poll' => $last,
                'invited' => isset($info['invited']) ? $info['invited'] : false
            );
        } else {
            $clean = true;
            unset($visitors[$name]);
        }
    }

    if ($clean) {
        write_json($visitor_file, $visitors);
    }

    // 统计每个访客的未读消息数
    $unread_counts = array();
    foreach ($messages as $m) {
        if ($m['from_type'] === 'visitor' && !$m['read']) {
            $from = $m['from'];
            if (!isset($unread_counts[$from])) {
                $unread_counts[$from] = 0;
            }
            $unread_counts[$from]++;
        }
    }

    json_out(array(
        'success' => true,
        'visitors' => $online,
        'messages' => $messages,
        'unread_counts' => $unread_counts
    ));
}

/**
 * 管理员发送消息给指定访客
 * GET: ?action=admin_send&target=xxx&message=xxx
 */
function action_admin_send() {
    global $msg_file;

    $target = isset($_GET['target']) ? trim($_GET['target']) : '';
    $message = isset($_GET['message']) ? trim($_GET['message']) : '';

    if ($target === '') {
        json_error('target is required');
    }
    if ($message === '') {
        json_error('message is required');
    }

    $messages = read_json($msg_file);
    $new_id = count($messages) + 1;

    $msg = array(
        'id' => $new_id,
        'from' => 'admin',
        'from_type' => 'admin',
        'to' => $target,
        'text' => $message,
        'time' => now(),
        'read' => false
    );
    $messages[] = $msg;
    write_json($msg_file, $messages);

    json_out(array(
        'success' => true,
        'id' => $new_id,
        'time' => $msg['time']
    ));
}

/**
 * 管理员邀请指定访客开始聊天
 * GET: ?action=admin_invite&target=xxx
 */
function action_admin_invite() {
    global $msg_file, $visitor_file;

    $target = isset($_GET['target']) ? trim($_GET['target']) : '';
    if ($target === '') {
        json_error('target is required');
    }

    // 更新访客邀请状态
    $visitors = read_json($visitor_file);
    if (isset($visitors[$target])) {
        $visitors[$target]['invited'] = true;
    } else {
        $visitors[$target] = array(
            'last_poll' => time(),
            'ip' => '',
            'first_seen' => now(),
            'invited' => true
        );
    }
    write_json($visitor_file, $visitors);

    // 发送一条系统邀请消息
    $messages = read_json($msg_file);
    $new_id = count($messages) + 1;
    $msg = array(
        'id' => $new_id,
        'from' => 'admin',
        'from_type' => 'admin',
        'to' => $target,
        'text' => '您好！客服邀请您开始聊天，有什么可以帮您的？',
        'time' => now(),
        'read' => false
    );
    $messages[] = $msg;
    write_json($msg_file, $messages);

    json_out(array(
        'success' => true,
        'target' => $target
    ));
}

// ==================== 内部辅助 ====================

/**
 * 更新访客在线状态
 */
function update_visitor($name) {
    global $visitor_file;

    $visitors = read_json($visitor_file);
    $now = time();
    $now_str = now();

    if (isset($visitors[$name])) {
        $visitors[$name]['last_poll'] = $now;
    } else {
        $visitors[$name] = array(
            'last_poll' => $now,
            'ip' => get_ip(),
            'first_seen' => $now_str,
            'invited' => false
        );
    }

    write_json($visitor_file, $visitors);
}
