<?php
/**
 * SWChat - 客服聊天系统 API
 * PHP 5.2 兼容版
 */
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

$data_dir = dirname(__FILE__) . '/data';
if (!is_dir($data_dir)) {
    mkdir($data_dir, 0777, true);
}

$msg_file     = $data_dir . '/messages.json';
$visitor_file = $data_dir . '/visitors.json';
$leave_file   = $data_dir . '/leaves.json';
$offline_flag = $data_dir . '/admin_offline.flag';
$heart_file   = $data_dir . '/admin_heartbeat.txt';
$deleted_file = $data_dir . '/deleted_visitors.json';

// ==================== 工具函数 ====================

function read_json($file) {
    if (!file_exists($file)) {
        return array();
    }
    $content = file_get_contents($file);
    if ($content === false || trim($content) === '') {
        return array();
    }
    $data = json_decode($content, true);
    if ($data === null) {
        return array();
    }
    return $data;
}

function write_json($file, $data) {
    $json = json_encode($data);
    if ($json === false) {
        return;
    }
    $tmp = $file . '.' . uniqid('', true) . '.tmp';
    $fp = @fopen($tmp, 'w');
    if ($fp) {
        @fwrite($fp, $json);
        @fclose($fp);
        @rename($tmp, $file);
    }
}

function get_client_ip() {
    if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        return trim($ips[0]);
    }
    if (isset($_SERVER['HTTP_CLIENT_IP'])) {
        return $_SERVER['HTTP_CLIENT_IP'];
    }
    return $_SERVER['REMOTE_ADDR'];
}

function generate_id() {
    return uniqid('', true);
}

function get_leave_unread() {
    global $leave_file;
    $leaves = read_json($leave_file);
    $unread = array();
    foreach ($leaves as $i => $l) {
        if (!$l['read']) {
            $unread[] = $l;
            $leaves[$i]['read'] = true;
        }
    }
    write_json($leave_file, $leaves);
    return $unread;
}

// ==================== 路由 ====================

$action = isset($_GET['action']) ? $_GET['action'] : '';

switch ($action) {

    // ========== 访客发送消息 ==========
    case 'send':
        $name    = isset($_POST['name'])    ? trim($_POST['name'])    : '';
        $message = isset($_POST['message']) ? trim($_POST['message']) : '';

        if ($name === '' || $message === '') {
            echo json_encode(array('error' => '参数缺失'));
            exit;
        }

        $name = strip_tags($name);
        $message = strip_tags($message);

        $messages = read_json($msg_file);
        $msg = array(
            'id'                  => generate_id(),
            'from'                => $name,
            'to'                  => 'admin',
            'text'                => $message,
            'time'                => date('H:i'),
            'delivered_to_admin'  => false,
            'delivered_to_visitor'=> true
        );
        $messages[] = $msg;
        write_json($msg_file, $messages);

        // 更新访客在线状态
        $visitors = read_json($visitor_file);
        $found = false;
        foreach ($visitors as $i => $v) {
            if ($v['name'] === $name) {
                $visitors[$i]['last_poll'] = time();
                $found = true;
                break;
            }
        }
        if (!$found) {
            $visitors[] = array(
                'name'      => $name,
                'ip'        => get_client_ip(),
                'last_poll' => time(),
                'invited'   => false,
                'first_seen'=> date('Y-m-d H:i:s')
            );
        }
        write_json($visitor_file, $visitors);

        echo json_encode(array('success' => true, 'msg_id' => $msg['id']));
        exit;

    // ========== 访客轮询新消息 ==========
    case 'poll':
        $name = isset($_GET['name']) ? trim($_GET['name']) : '';
        if ($name === '') {
            echo json_encode(array('error' => '参数缺失'));
            exit;
        }
        $name = strip_tags($name);

        $messages = read_json($msg_file);
        $visitors = read_json($visitor_file);

        // 收集发给该访客且未投递的消息
        $new_msgs = array();
        foreach ($messages as $i => $msg) {
            if ($msg['to'] === $name && isset($msg['delivered_to_visitor']) && !$msg['delivered_to_visitor']) {
                $new_msgs[] = $msg;
                $messages[$i]['delivered_to_visitor'] = true;
            }
        }
        write_json($msg_file, $messages);

        // 被删除的访客再次 poll 时，自动移出黑名单
        $deleted_list = read_json($deleted_file);
        if (in_array($name, $deleted_list)) {
            $deleted_list = array_values(array_diff($deleted_list, array($name)));
            write_json($deleted_file, $deleted_list);
        }

        // 更新访客在线状态 & 获取是否被邀请
        $invited = false;
        $found = false;
        foreach ($visitors as $i => $v) {
            if ($v['name'] === $name) {
                $visitors[$i]['last_poll'] = time();
                $invited = $v['invited'];
                $found = true;
                break;
            }
        }
        if (!$found) {
            $visitors[] = array(
                'name'      => $name,
                'ip'        => get_client_ip(),
                'last_poll' => time(),
                'invited'   => false,
                'first_seen'=> date('Y-m-d H:i:s'),
                'alias'     => ''
            );
        }
        write_json($visitor_file, $visitors);

        // 判断管理员是否在线 —— 文件锁 + 心跳文件（双重保障）
        $admin_online = false;
        if (!file_exists($offline_flag) && file_exists($heart_file)) {
            clearstatcache(true, $heart_file);
            if ((time() - filemtime($heart_file)) < 15) {
                $admin_online = true;
            }
        }

        echo json_encode(array(
            'messages'     => $new_msgs,
            'invited'      => $invited,
            'admin_online' => $admin_online
        ));
        exit;

    // ========== 管理端轮询 ==========
    case 'admin_poll':
        // 文件锁判断手动离线：auto 表示页面关闭自动标记，重启后自动清除
        $manual_offline = false;
        if (file_exists($offline_flag)) {
            $flag_content = @file_get_contents($offline_flag);
            if ($flag_content === 'auto') {
                // 自动标记：清除 flag，恢复在线
                @unlink($offline_flag);
            } else {
                // 手动离线：持久化，需手动点击上线
                $manual_offline = true;
            }
        }
        if (!$manual_offline) {
            // 更新心跳文件 —— filemtime 由文件系统维护，零竞态
            @file_put_contents($heart_file, time());
        }

        $last_id = isset($_GET['last_id']) ? $_GET['last_id'] : '';

        $messages = read_json($msg_file);
        $visitors = read_json($visitor_file);

        // 获取未投递给管理员的新消息
        $new_msgs = array();
        $max_id = $last_id;
        foreach ($messages as $i => $msg) {
            if (isset($msg['delivered_to_admin']) && !$msg['delivered_to_admin']) {
                if (!isset($msg['read'])) {
                    $msg['read'] = false;
                }
                $new_msgs[] = $msg;
                $messages[$i]['read'] = $msg['read'];
                $messages[$i]['delivered_to_admin'] = true;
            }
            $max_id = $msg['id'];
        }
        write_json($msg_file, $messages);

        // 被删除的访客再次发来消息时，自动移出黑名单
        $deleted_list = read_json($deleted_file);
        $deleted_changed = false;
        foreach ($new_msgs as $nm) {
            $from_name = $nm['from'];
            $idx = array_search($from_name, $deleted_list);
            if ($idx !== false) {
                unset($deleted_list[$idx]);
                $deleted_list = array_values($deleted_list);
                $deleted_changed = true;
            }
        }
        if ($deleted_changed) {
            write_json($deleted_file, $deleted_list);
        }

        // 构建在线访客列表 (3秒内有轮询的)
        $now = time();
        $online_visitors = array();
        foreach ($visitors as $v) {
            if (($now - $v['last_poll']) < 15) {
                $v['online'] = true;
            } else {
                $v['online'] = false;
            }
            $online_visitors[] = $v;
        }

        echo json_encode(array(
            'messages'         => $new_msgs,
            'visitors'         => $online_visitors,
            'leaves'           => get_leave_unread(),
            'manual_offline'   => $manual_offline,
            'deleted_visitors' => $deleted_list
        ));
        exit;

    // ========== 管理端发送消息 ==========
    case 'admin_send':
        $target  = isset($_POST['target'])  ? trim($_POST['target'])  : '';
        $message = isset($_POST['message']) ? trim($_POST['message']) : '';

        if ($target === '' || $message === '') {
            echo json_encode(array('error' => '参数缺失'));
            exit;
        }
        $target  = strip_tags($target);
        $message = strip_tags($message);

        $messages = read_json($msg_file);
        $msg = array(
            'id'                  => generate_id(),
            'from'                => 'admin',
            'to'                  => $target,
            'text'                => $message,
            'time'                => date('H:i'),
            'delivered_to_admin'  => true,
            'delivered_to_visitor'=> false,
            'auto_open'           => true
        );
        $messages[] = $msg;
        write_json($msg_file, $messages);

        echo json_encode(array('success' => true, 'msg_id' => $msg['id']));
        exit;

    // ========== 管理端邀请访客 ==========
    case 'admin_invite':
        // 离线时禁止发起聊天邀请
        if (file_exists($offline_flag)) {
            echo json_encode(array('error' => '客服离线中，无法发送邀请'));
            exit;
        }
        $visitor_name = isset($_GET['visitor']) ? trim($_GET['visitor']) : '';
        if ($visitor_name === '') {
            echo json_encode(array('error' => '参数缺失'));
            exit;
        }
        $visitor_name = strip_tags($visitor_name);

        $visitors = read_json($visitor_file);
        $found = false;
        foreach ($visitors as $i => $v) {
            if ($v['name'] === $visitor_name) {
                $visitors[$i]['invited'] = true;
                $found = true;
                break;
            }
        }
        if ($found) {
            write_json($visitor_file, $visitors);
            echo json_encode(array('success' => true, 'visitor' => $visitor_name));
        } else {
            echo json_encode(array('error' => '访客不存在'));
        }
        exit;

    // ========== 获取与某访客的聊天记录 ==========
    case 'chat_history':
        $visitor_name = isset($_GET['visitor']) ? trim($_GET['visitor']) : '';
        if ($visitor_name === '') {
            echo json_encode(array('error' => '参数缺失'));
            exit;
        }
        $visitor_name = strip_tags($visitor_name);

        $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 0;
        $before_id = isset($_GET['before_id']) ? trim($_GET['before_id']) : '';

        $messages = read_json($msg_file);
        $history = array();
        $before_found = ($before_id === '');
        foreach ($messages as $msg) {
            if (($msg['from'] === $visitor_name && $msg['to'] === 'admin') ||
                ($msg['from'] === 'admin' && $msg['to'] === $visitor_name)) {
                if (!$before_found) {
                    if ($msg['id'] === $before_id) { $before_found = true; }
                    continue;
                }
                if (!isset($msg['read'])) { $msg['read'] = false; }
                $history[] = $msg;
            }
        }
        // 只取最后 N 条
        if ($limit > 0 && count($history) > $limit) {
            $history = array_slice($history, -$limit);
        }
        $has_more = ($limit > 0 && count($history) >= $limit);

        echo json_encode(array('messages' => $history, 'total' => count($messages), 'has_more' => $has_more));
        exit;

    // ========== 获取访客名称（基于IP归属地） ==========
    case 'get_name':
        $ip = get_client_ip();

        // 检查是否已存在该IP对应的访客
        $visitors = read_json($visitor_file);
        foreach ($visitors as $v) {
            if ($v['ip'] === $ip) {
                echo json_encode(array('name' => $v['name']));
                exit;
            }
        }

        // 查询IP归属地
        $city = '';
        $geo_url = 'http://ip-api.com/json/' . $ip . '?lang=zh-CN&fields=city';
        $ctx = stream_context_create(array('http' => array('timeout' => 3)));
        $geo_data = @file_get_contents($geo_url, false, $ctx);
        if ($geo_data !== false) {
            $geo_json = json_decode($geo_data, true);
            if ($geo_json !== null && isset($geo_json['city']) && $geo_json['city'] !== '') {
                $city = $geo_json['city'];
            }
        }

        // 生成名称
        $suffix = strval(mt_rand(1000, 9999));
        if ($city !== '') {
            $name = $city . '访客' . $suffix;
        } else {
            $name = '访客' . $suffix;
        }

        echo json_encode(array('name' => $name));
        exit;

    // ========== 修改访客备注名 ==========
    case 'update_alias':
        $old_name = isset($_POST['name'])     ? trim($_POST['name'])     : '';
        $new_name = isset($_POST['alias'])    ? trim($_POST['alias'])    : '';

        if ($old_name === '' || $new_name === '') {
            echo json_encode(array('error' => '参数缺失'));
            exit;
        }
        $old_name = strip_tags($old_name);
        $new_name = strip_tags($new_name);

        $visitors = read_json($visitor_file);
        $found = false;
        foreach ($visitors as $i => $v) {
            if ($v['name'] === $old_name) {
                $visitors[$i]['alias'] = $new_name;
                $found = true;
                break;
            }
        }
        if ($found) {
            write_json($visitor_file, $visitors);
            echo json_encode(array('success' => true, 'alias' => $new_name));
        } else {
            echo json_encode(array('error' => '访客不存在'));
        }
        exit;

    // ========== 访客留言 ==========
    case 'leave_message':
        $leave_name    = isset($_POST['name'])    ? trim($_POST['name'])    : '';
        $leave_phone   = isset($_POST['phone'])   ? trim($_POST['phone'])   : '';
        $leave_content = isset($_POST['content']) ? trim($_POST['content']) : '';

        if ($leave_name === '' || $leave_phone === '' || $leave_content === '') {
            echo json_encode(array('error' => '请填写完整的留言信息'));
            exit;
        }
        $leave_name    = strip_tags($leave_name);
        $leave_phone   = strip_tags($leave_phone);
        $leave_content = strip_tags($leave_content);

        $leaves = read_json($leave_file);
        $leaves[] = array(
            'id'      => generate_id(),
            'name'    => $leave_name,
            'phone'   => $leave_phone,
            'content' => $leave_content,
            'time'    => date('Y-m-d H:i:s'),
            'read'    => false
        );
        write_json($leave_file, $leaves);

        echo json_encode(array('success' => true));
        exit;

    // ========== 管理员设置在线/离线状态 ==========
    case 'admin_status':
        $status = isset($_GET['status']) ? trim($_GET['status']) : '';
        $reason = isset($_GET['reason']) ? trim($_GET['reason']) : 'manual';
        if ($status !== 'online' && $status !== 'offline') {
            echo json_encode(array('error' => 'status 参数需为 online 或 offline'));
            exit;
        }
        if ($status === 'offline') {
            // reason=auto: 页面关闭自动标记，重启时自动清除
            // reason=manual: 手动离线，持久化不自动清除
            @file_put_contents($offline_flag, $reason === 'auto' ? 'auto' : 'offline');
        } else {
            @unlink($offline_flag);
            @file_put_contents($heart_file, time());
        }
        echo json_encode(array('success' => true, 'status' => $status));
        exit;

    // ========== 获取未读留言（管理端） ==========
    case 'get_leaves':
        $leaves = read_json($leave_file);
        $unread = array();
        foreach ($leaves as $i => $l) {
            if (!$l['read']) {
                $unread[] = $l;
                $leaves[$i]['read'] = true;
            }
        }
        write_json($leave_file, $leaves);
        echo json_encode(array('leaves' => $unread));
        exit;

    // ========== 访客删除聊天记录 ==========
    case 'delete_visitor_messages':
        $visitor_name = isset($_POST['name']) ? trim($_POST['name']) : '';
        if ($visitor_name === '') {
            echo json_encode(array('error' => '参数缺失'));
            exit;
        }
        $visitor_name = strip_tags($visitor_name);
        $messages = read_json($msg_file);
        $new_messages = array();
        $deleted = 0;
        foreach ($messages as $m) {
            if (($m['from'] === $visitor_name && $m['to'] === 'admin') ||
                ($m['from'] === 'admin' && $m['to'] === $visitor_name)) {
                $deleted++;
            } else {
                $new_messages[] = $m;
            }
        }
        write_json($msg_file, $new_messages);
        echo json_encode(array('success' => true, 'deleted' => $deleted));
        exit;

    // ========== 标记删除访客窗口 ==========
    case 'mark_deleted':
        $visitor_name = isset($_POST['name']) ? trim($_POST['name']) : '';
        if ($visitor_name === '') {
            echo json_encode(array('error' => '参数缺失'));
            exit;
        }
        $visitor_name = strip_tags($visitor_name);
        $deleted = read_json($deleted_file);
        if (!in_array($visitor_name, $deleted)) {
            $deleted[] = $visitor_name;
            write_json($deleted_file, $deleted);
        }
        echo json_encode(array('success' => true));
        exit;


    // ========== 标记访客消息已读 ==========
    case 'mark_read':
        $visitor_name = isset($_POST['name']) ? trim($_POST['name']) : '';
        if ($visitor_name === '') {
            echo json_encode(array('error' => '参数缺失'));
            exit;
        }
        $visitor_name = strip_tags($visitor_name);
        $messages = read_json($msg_file);
        $count = 0;
        foreach ($messages as $i => $msg) {
            if (($msg['from'] === $visitor_name && $msg['to'] === 'admin') ||
                ($msg['from'] === 'admin' && $msg['to'] === $visitor_name)) {
                if (!isset($msg['read']) || !$msg['read']) {
                    $messages[$i]['read'] = true;
                    $count++;
                }
            }
        }
        write_json($msg_file, $messages);
        echo json_encode(array('success' => true, 'marked' => $count));
        exit;

    default:
        echo json_encode(array('error' => '未知操作', 'action' => $action));
        exit;
}
